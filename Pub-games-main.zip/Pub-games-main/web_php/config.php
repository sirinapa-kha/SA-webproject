<?php
$conn = mysqli_connect('localhost','root','','db_webboard') or die('Error connecting database!');
mysqli_set_charset($conn,'utf8');
